All Windows Versions
Simplify3D Backup Script

This Script make a backup of all S3D Registry entries. And i mean ALL!
In the backup will be your Cloud Token and your Login stored, so keep it safe!